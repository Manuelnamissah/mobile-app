import 'package:flutter/material.dart';

void main() {
  runApp(CourseDashboardApp());
}

class CourseDashboardApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: CourseDashboard(),
    );
  }
}

class CourseDashboard extends StatefulWidget {
  @override
  _CourseDashboardState createState() => _CourseDashboardState();
}

class _CourseDashboardState extends State<CourseDashboard> {
  int _selectedIndex = 0;
  String selectedCategory = "None";
  double buttonSize = 100;

  final List<Map<String, String>> courses = [
    {"name": "Mobile Development", "instructor": "Dr. Smith"},
    {"name": "Database Systems", "instructor": "Prof. Johnson"},
    {"name": "Networking", "instructor": "Dr. Lee"},
    {"name": "AI Fundamentals", "instructor": "Dr. Brown"},
    {"name": "Web Development", "instructor": "Prof. Adams"},
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Course Dashboard")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (_selectedIndex == 0)
              Text("Home Screen", style: TextStyle(fontSize: 22)),
            if (_selectedIndex == 1)
              Expanded(
                child: ListView.builder(
                  itemCount: courses.length,
                  itemBuilder: (context, index) {
                    return ListTile(
                      leading: Icon(Icons.book),
                      title: Text(courses[index]["name"]!),
                      subtitle: Text("Instructor: ${courses[index]["instructor"]}"),
                    );
                  },
                ),
              ),
            if (_selectedIndex == 2)
              Column(
                children: [
                  ElevatedButton(
                    onPressed: () {
                      showDialog(
                        context: context,
                        builder: (context) => AlertDialog(
                          title: Text("Logout"),
                          content: Text("Are you sure you want to exit the app?"),
                          actions: [
                            TextButton(
                              onPressed: () => Navigator.pop(context),
                              child: Text("No"),
                            ),
                            TextButton(
                              onPressed: () => Navigator.pop(context),
                              child: Text("Yes"),
                            ),
                          ],
                        ),
                      );
                    },
                    child: Text("Logout"),
                  ),
                  SizedBox(height: 20),
                  AnimatedContainer(
                    duration: Duration(milliseconds: 300),
                    height: buttonSize,
                    width: buttonSize,
                    child: ElevatedButton(
                      onPressed: () {
                        setState(() {
                          buttonSize = buttonSize == 100 ? 150 : 100;
                        });
                      },
                      child: Text("Enroll"),
                    ),
                  ),
                  SizedBox(height: 20),
                  DropdownButton<String>(
                    value: selectedCategory == "None" ? null : selectedCategory,
                    hint: Text("Select Category"),
                    items: ["Science", "Arts", "Technology"]
                        .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                        .toList(),
                    onChanged: (value) {
                      setState(() {
                        selectedCategory = value!;
                      });
                    },
                  ),
                  Text("Selected Category: $selectedCategory"),
                ],
              ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
          BottomNavigationBarItem(icon: Icon(Icons.book), label: "Courses"),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profile"),
        ],
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
      ),
    );
  }
}