import 'package:flutter/material.dart';

void main() {
  runApp(StudentInfoManagerApp());
}

class StudentInfoManagerApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: StudentHomePage(),
    );
  }
}

class StudentHomePage extends StatefulWidget {
  @override
  _StudentHomePageState createState() => _StudentHomePageState();
}

class _StudentHomePageState extends State<StudentHomePage> {
  int studentCount = 0;
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  String? errorMessage;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Student Info Manager")),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text("Name: John Doe\nCourse: INFT 356\nUniversity: XYZ University",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text("Hello, John Doe! Welcome to the Student Info Manager.")),
                );
              },
              child: Text("Show Alert"),
            ),
            SizedBox(height: 16),
            Text("Students Enrolled: $studentCount", style: TextStyle(fontSize: 20)),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(icon: Icon(Icons.remove), onPressed: () {
                  setState(() { if (studentCount > 0) studentCount--; });
                }),
                IconButton(icon: Icon(Icons.add), onPressed: () {
                  setState(() { studentCount++; });
                }),
              ],
            ),
            SizedBox(height: 16),
            TextField(
              controller: _emailController,
              decoration: InputDecoration(labelText: "Email"),
            ),
            TextField(
              controller: _passwordController,
              obscureText: true,
              decoration: InputDecoration(labelText: "Password"),
            ),
            if (errorMessage != null) 
              Text(errorMessage!, style: TextStyle(color: Colors.red)),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  if (!_emailController.text.contains("@")) {
                    errorMessage = "Invalid email";
                  } else if (_passwordController.text.length < 6) {
                    errorMessage = "Password must be at least 6 characters";
                  } else {
                    errorMessage = null;
                  }
                });
              },
              child: Text("Login"),
            ),
            SizedBox(height: 16),
            Image.network(
              "https://picsum.photos/200",
              height: 150,
              width: 150,
              fit: BoxFit.cover,
            ),
          ],
        ),
      ),
    );
  }
}